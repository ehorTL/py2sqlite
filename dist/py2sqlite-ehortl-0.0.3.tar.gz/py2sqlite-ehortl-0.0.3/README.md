# py2sqlite
py2sqlite package repository
